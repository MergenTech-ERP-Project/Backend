package com.mergen.vtys.vtysdatabaseap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VtysDatabaseApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(VtysDatabaseApiApplication.class, args);
    }

}
